#include <stdio.h>
#include <mysql.h>

int main(int argc,char *argv[])
{
	MYSQL conn;
	int res;
	char sql[512];

	if( argc!=4 ){
		fprintf(stderr, "Usage:%s name email age\n", argv[0]);
		return -2;
	}

	mysql_init(&conn);//初始化 连接
	if(mysql_real_connect(&conn,"localhost","root","asdf","test",
		0,NULL,CLIENT_FOUND_ROWS))
	{
		printf("数据库连接成功\n");
		//插入语句，成功返回0，失败返回1
		sprintf(sql, "insert into person(`name`, `email`, `age`) "
			"values('%s', '%s', %d)", argv[1], argv[2], atoi(argv[3]));
		res = mysql_query(&conn, sql);
		if(res)
		{
			printf("语句执行失败\n");
			mysql_close(&conn);//记得关闭连接
		}
		else
		{
			printf("语句执行成功\n");
			mysql_close(&conn);
		}
	}       
	return 0;
}
