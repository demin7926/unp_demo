#ifndef TEXT_PARSE_H_
#define TEXT_PARSE_H_

#include "global.h"


#ifdef __cplusplus
extern "C"
{
#endif



void parse_start(const char *decmp_path);



#ifdef __cplusplus
}; //end of extern "C" {
#endif


#endif
