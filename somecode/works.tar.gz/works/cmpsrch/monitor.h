#ifndef M_MONITOR_H_
#define M_MONITOR_H_

#include "global.h"

//monitor the creating operation on target direcoty
void monitor_dir(const char *target);

#endif
