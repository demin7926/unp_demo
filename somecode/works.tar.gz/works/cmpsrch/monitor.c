#include <sys/stat.h>
#include <time.h>
#include "monitor.h"
#include "text_parse.h"


extern char decmp_dir[MAXLINE];
extern char mon_dir[MAXLINE];


/**
 * reading inotify event message
 */
static int freadsome(void *dest, size_t remain, FILE *file)
{
	char *offset = (char*)dest;
	while (remain) {
		int n = fread(offset, 1, remain, file);
		if (n==0) {
			return -1;
		}

		remain -= n;
		offset += n;
	}
	return 0;
}

static void file_create_func(const char *path)
{
	char path_add[512], path_decmp[512], cmd[512];
	struct stat buf;
	
	sprintf(path_add, "%s/%s\0", mon_dir, path);
	if(stat(path_add, &buf)<0){
		perror("stat fail");
		return;
	}

	if( !S_ISREG(buf.st_mode) ){
		printf("\"%s\" is not a regular file, ignored\n", path_add);
		return;
	}

	if( strstr(path, ".tar.gz")==NULL ){
		printf("\"%s\" doesn't matchs \"*.tar.gz\", ignored\n", path_add);
		return;
	}

	sprintf(path_decmp, "%s/%ld\0", decmp_dir, time(NULL));
	if( mkdir(path_decmp, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)<0 ){
		fprintf(stderr, "mkdir(\"%s\") fail:%s\n", path_decmp, strerror(errno));
		return;
	}
	sprintf(cmd, "tar -zxf %s -C %s\0", path_add, path_decmp);
	//printf("\n\tOK:%s\n\n", cmd);
	//create a child process to handle the .tar.gz file
	if( fork()==0 ){
		if( system(cmd)<0 ){
			fprintf(stderr, "%s fail:%s\n", cmd, strerror(errno));
			return;		
		}

		parse_start(path_decmp);	
	}//if fork==0

}


/**
 * monitor the creating operation on target direcoty
 */
void monitor_dir(const char *target)
{
	int monitor = inotify_init();
	if ( -1 == monitor ) {
		ERROR("monitor");
	}

	int watcher = inotify_add_watch(monitor, target, IN_ALL_EVENTS);
	if ( -1 == watcher  ) {
		ERROR("inotify_add_watch");
	}

	FILE *monitor_file = fdopen(monitor, "r");
	char last_name[1024];
	char name[1024];

	/* event:inotify_event -> name:char[event.len] */
	while (1) {
		struct inotify_event event;
		if ( -1 == freadsome(&event, sizeof(event), monitor_file) ) {
			ERROR("freadsome");
		}
		if (event.len) {
			freadsome(name, event.len, monitor_file);
		} else {
			sprintf(name, "FD: %d\n", event.wd);
		}

		if (strcmp(name, last_name) != 0) {
			strcpy(last_name, name);
			//if is creating a new file
			if (event.mask & IN_CREATE) {
				//printf("%s is created\n", name);
				file_create_func(name);
			}
		}
	}//while
	
}
