#include "PersonModel.h"

void PersonModel::showAll()
{
	if(!this->conn)return;

	char sql[] = "SELECT id, name, email, age FROM person";
	int res = mysql_real_query(&this->conn, sql, strlen(sql));
	if(res==0){
		this->presult = mysql_use_result(&this->conn);
		if(this->presult){
			MYSQL_ROW row;
			while((row=mysql_fetch_row(this->presult))){
				printf("%10d%20s%40s%10d", row[0], row[1], row[2], row[3]);	
			}//while
			mysql_free_result(this->presult);
		}
	}else{
		cout<<this->getLastError();
	}

}//showAll()
