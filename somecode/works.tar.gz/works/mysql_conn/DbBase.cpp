#include <DbBase.h>

DbBase::DbBase()
{
	mysql_init(&conn);
	if( mysql_real_connect(&conn, _db_host, _db_username, _db_password, 
		_db_name, 0, NULL, CLIENT_FOUND_ROWS)==NULL )
	{
		exit(-5);
	}
}

DbBase::~DbBase()
{
	if(conn)
		mysql_close(conn);
}

int DbBase::exec(string sql)
{
	if(!conn)return -1;
	mysql_query(&conn, sql);
	return mysql_affected_rows();
}

const char* DbBase::getLastError()
{
	if(!conn)return NULL;
	return mysql_error(&conn);
}
