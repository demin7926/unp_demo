#include "global.h"
#include "inifile.h"
#include "monitor.h"

char mon_dir[MAXLINE];
char decmp_dir[MAXLINE];
char config_file[] = "cmpsrch.ini";

int main(int argc, char *argv[])
{
	if(!read_profile_string("monitor", "monitor_dir", 
		mon_dir, MAXLINE, "", config_file)){
		fprintf(stderr, "read ini file fail\n");
		return ME_INI;
	}

	if(!read_profile_string("monitor", "decmp_dir", 
		decmp_dir, MAXLINE, "", config_file)){
		fprintf(stderr, "read ini file fail\n");
		return ME_INI;
	}
	
	monitor_dir(mon_dir);
	

	return 0;
}
