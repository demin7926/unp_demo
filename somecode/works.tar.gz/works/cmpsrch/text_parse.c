#include "text_parse.h"

void parse_start(const char *decmp_path)
{
	printf("parse_start:%s\n", decmp_path);
}
