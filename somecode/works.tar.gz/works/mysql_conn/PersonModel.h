#ifndef PERSON_MODEL_H_
#define PERSON_MODEL_H_



#include "DbBase.h"

class PersonModel : public DbBase
{
public:
	PersonModel():DbBase(){}
	~Person():~DbBase(){}

	//show all person data in the table
	void showAll();
};




#endif //end PERSON_MODEL_H_
