#include "global.h"


void parse_start(const char *decmp_path);
