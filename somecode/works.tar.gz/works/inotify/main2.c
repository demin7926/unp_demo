#include<stdio.h>
#include<unistd.h>
#include<sys/inotify.h>

#define MAX_EVENTS 256
#define BUFFER_SIZE (MAX_EVENTS * sizeof(struct inotify_event))

int main(int argc , char *argv[])
{
	int i=0;
	int len;
	int inotify_fd;
	int inotify_wd;
	int inotify_err;
	struct inotify_event *ievent;

	if( argc != 2 )
	{
		printf("no input !");	
		return -1;
	}

	inotify_fd = inotify_init();
	if ( inotify_fd < 0 )
		printf("can't init inotify ");

	inotify_wd=inotify_add_watch(inotify_fd, argv[1] , IN_CREATE );

	while(1)
	{
		i=0;
		char ev_buffer[BUFFER_SIZE];
		len= read(inotify_fd, ev_buffer,BUFFER_SIZE);
		while(i<len)
		{

			ievent=(struct inotify_event *)&ev_buffer[i];
			if (ievent->len) printf("[%s]",ievent->name);
			if(ievent->mask & IN_CREATE ) printf("create");
		}
	}
}	
