#include <stdlib.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#include "monitor.h"
#include "text_parse.h"

#ifdef __cplusplus
extern "C"
{

#endif

extern char decmp_dir[MAXLINE];
extern char mon_dir[MAXLINE];


/**
 * reading inotify event message
 */
static int freadsome(void *dest, size_t remain, FILE *file)
{
	char *offset = (char*)dest;
	while (remain) {
		int n = fread(offset, 1, remain, file);
		if (n==0) {
			return -1;
		}

		remain -= n;
		offset += n;
	}
	return 0;
}

static void file_create_func(const char *path)
{
	char path_add[512], path_decmp[512], cmd[512];
	struct stat buf;
	bzero(path_add, sizeof(path_add));
	sprintf(path_add, "%s/%s", mon_dir, path);
	bzero(path_decmp, sizeof(path_decmp));
	sprintf(path_decmp, "%s/%s", decmp_dir, path);

	if(stat(path_add, &buf)<0){
		perror("stat fail");
		return;
	}

	if( !S_ISREG(buf.st_mode) ){
		printf("\"%s\" is not a regular file, ignored\n", path_add);
		return;
	}
	if( strstr(path, ".gz")==NULL || strstr(path, ".gzip")==NULL ){
		printf("\"%s\" is not a gzip format, ignored\n", path_add);
		return;
	}
		
	bzero(cmd, sizeof(cmd));
	sprintf(cmd, "mv %s %s/ && gunzip -S .gzip %s", 
		path_add, decmp_dir, path_decmp);

	//printf("\n\tOK:%s\n\n", cmd);
	if( fork()==0 ){
		if( system(cmd)<0 ){
			fprintf(stderr, "%s fail:%s\n", cmd, strerror(errno));
			return;		
		}

		//printf("begin parse_start(\"%s\")\n", path_decmp);
		parse_start(path_decmp);	
	}//if fork==0

}


/**
 * monitor the creating operation on target direcoty
 */
void monitor_dir(const char *target)
{
	int monitor = inotify_init();
	if ( -1 == monitor ) {
		ERROR("monitor");
	}

	int watcher = inotify_add_watch(monitor, target, IN_ALL_EVENTS);
	if ( -1 == watcher  ) {
		ERROR("inotify_add_watch");
	}

	FILE *monitor_file = fdopen(monitor, "r");
	if( monitor_file==NULL ){
		perror("fdopen fail");	
		return;
	}else{
		printf("added watch on %s\n", target);
	}
	char last_name[1024];
	char name[1024];

	/* event:inotify_event -> name:char[event.len] */
	while (1) {
		struct inotify_event event;
		if ( -1 == freadsome(&event, sizeof(event), monitor_file) ) {
			ERROR("freadsome");
		}
		if (event.len) {
			freadsome(name, event.len, monitor_file);
		} else {
			sprintf(name, "FD: %d\n", event.wd);
		}

		if (strcmp(name, last_name) != 0) {
			strcpy(last_name, name);
			if (event.mask & IN_CREATE) {
				//printf("%s is created\n", name);
				file_create_func(name);
			}
		}
	}//while
	
	fclose(monitor_file);
}

#ifdef __cplusplus
}; //end of extern "C" {
#endif
