#ifndef DB_BASE_H_
#define DB_BASE_H_

#include <string>
#include <mysql.h>
using namespace std;

class DbBase
{
public:
	DbBase();
	virtual ~DbBase();

	//execute update, delete query, and return the affected rows
	int exec(string sql);

	const char* getLastError();

protected:
	MYSQL conn;
	MYSQL_RES result;
	MYSQL_RES *presult;

private:
	string _db_host("localhost");
	string _db_username("root");
	string _db_password("adf");
	string _db_name("test");
};



#endif		//end ifndef DB_BASE_H_
