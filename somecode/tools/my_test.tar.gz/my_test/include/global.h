#ifndef M_GLOBAL_H
#define M_GLOBAL_H

#include <unistd.h>
#include <sys/inotify.h>
#include <stdio.h>
#include <error.h>
#include <errno.h>
#include <string.h>

#define MAXLINE 256
#define ERROR(text) error(1, errno, "%s", text)


#define ME_INI		-101
#define ME_USAGE	-102
#define ME_IO		-103
#define ME_DB		-104
#define ME_OTHER	-109


#endif
