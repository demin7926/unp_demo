#include "text_parse.h"
#include <json/json.h>
#include <fcntl.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define BUF_MAX (1024*1024*4)		//4M buffer for the text file

void parse_start(const char *decmp_path)
{
	//printf("in parse_start(\"%s\")\n", decmp_path);
	
	int filefd, n=0;
	char buf[BUF_MAX], path[MAXLINE], *pos;
	Json::Reader reader;
	Json::Value value;

	bzero(path, sizeof(path));
	strcpy(path, decmp_path);

	//remove the extension after gunzip
	pos = strcasestr(path, ".gz");
	if(pos)*pos = 0;

	if( (filefd=open(path, O_RDONLY))<0 ){
		fprintf(stderr, "open file %s fail:%s\n", path, strerror(errno));
		return;
	}
	
	while( (n=read(filefd, buf+n, sizeof(buf)-n))>0 ){}

	if (reader.parse(buf, value)){
		printf("json value size:%d\n", value.size());

		const Json::Value arrayObj = value["appInfo"];
		//Json::Value appItemObj;
		for (unsigned int i = 0; i < arrayObj.size(); i++)
		{
			std::cout<<arrayObj[i]["appName"].asString()<<std::endl;
		}


	}else{
		fprintf(stderr, "Json parse faild!\n");
		return;
	}
	
	close(filefd);
}



#ifdef __cplusplus
}; //end of extern "C" {
#endif
