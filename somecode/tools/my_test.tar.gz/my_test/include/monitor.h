#ifndef M_MONITOR_H_
#define M_MONITOR_H_

#include "global.h"

#ifdef __cplusplus
extern "C"
{

#endif


//monitor the creating operation on target direcoty
void monitor_dir(const char *target);

#ifdef __cplusplus
}; //end of extern "C" {
#endif

#endif
