#include <string.h>
#include <stdio.h>

int main(void)
{
	char str[] = "123456.gzip";
	char *pos;

	pos = strcasestr(str, ".gz");

	printf("%s\npos:%s\n", str, pos);

	return 0;
}
