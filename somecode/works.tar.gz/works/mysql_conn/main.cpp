#include <stdio.h>
#include "PersonModel.h"

int main(void)
{
	PersonModel pm;
	pm.showAll();
	
	return 0;
}
