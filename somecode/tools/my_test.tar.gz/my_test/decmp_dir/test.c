#include <stdio.h>
#include <fcntl.h>
#include <string.h>

#define BUF_MAX (1024*1024*4)

int main(int argc, char *argv[])
{
	if(argc!=2)
		return -1;
	
	int filefd, n=0;
	char buf[BUF_MAX];

	if( (filefd=open(argv[1], O_RDONLY))==-1 ){
		perror("open fail");
		return -1;
	}

	bzero(buf, sizeof(buf));
	while( (n=read(filefd, buf+n, sizeof(buf)))>0 ){}

	

	printf("%s", buf);
	
	close(filefd);
	return 0;
}
