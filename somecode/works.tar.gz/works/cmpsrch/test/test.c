#include <stdio.h>
#include <time.h>

int main(void)
{
	printf("time:%ld\n", (long)time(NULL));

	return 0;
}
